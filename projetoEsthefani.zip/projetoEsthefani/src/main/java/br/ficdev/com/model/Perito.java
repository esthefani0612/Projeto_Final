package br.ficdev.com.model;

public class Perito {

}
